use ClientDB
CREATE TABLE Client_A_Contacts 
(
first_name varchar(30),
last_name varchar(30),
city varchar(30),
county varchar(30),
zip varchar(30),
officePhone varchar(30),
mobilePhone varchar(30)
) 
